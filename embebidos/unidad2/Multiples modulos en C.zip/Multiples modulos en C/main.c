#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "uart_example.h"

#define LED_PIN         GPIO_NUM_2
#define UART_BUF_SIZE   (1024)
#define UART_RX_PIN     (3)
#define UART_TX_PIN     (1)
#define MSG_BUF_SIZE    (64)

void led_task(void *arg)
{
  while (1) 
  {
    gpio_set_level(LED_PIN, 1);
    vTaskDelay(500 / portTICK_PERIOD_MS);
    gpio_set_level(LED_PIN, 0);
    vTaskDelay(500 / portTICK_PERIOD_MS);
  }
}

void print_task(void *arg)
{
  char msg[MSG_BUF_SIZE];
  uint8_t cnt = 0;
  
  ESP_ERROR_CHECK(uart_init(UART_NUM_0, UART_TX_PIN, UART_RX_PIN, UART_BUF_SIZE, UART_BUF_SIZE));
  
  while (1)
  {
    snprintf(msg,MSG_BUF_SIZE,"Hola %d\n",cnt++);
    ESP_ERROR_CHECK(uart_puts(msg));
    vTaskDelay(1000 / portTICK_PERIOD_MS);
  }
}


void app_main() 
{
  gpio_reset_pin(LED_PIN); /* Tarea: Pase el manejo de LEDs a otro módulo (archivos .c y .h) */
  gpio_set_direction(LED_PIN, GPIO_MODE_OUTPUT);
  
  xTaskCreate(led_task, "led_task", 2048, NULL, 10, NULL);
  xTaskCreate(print_task, "print_task", 2048, NULL, 10, NULL);
}

