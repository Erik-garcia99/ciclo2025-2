#ifndef __UART_EXAMPLE_H__ /* Directiva de preprocesador. Llamada Header guard, Include guard o guardián de inclusión múltiple */
#define __UART_EXAMPLE_H__


/**
  * @brief     Init a UART port
  *
  * @param     uart_num  UART port
  * @param     tx_pin  UART TX pin
  * @param     rx_pin  UART RX pin
  * @param     tx_buffer_size  TX ring buffer size
  * @param     rx_buffer_size  RX ring buffer size
  *
  * @return
  *    - ESP_OK
  *    - ESP_FAIL
  */
esp_err_t uart_init(uart_port_t uart_num, uint8_t tx_pin, uint8_t rx_pin, uint16_t tx_buffer_size, uint16_t rx_buffer_size);

/**
  * @brief     Write a string via UART.
  *
  * @param     str  A null-terminated string.
  *
  * @return
  *    - ESP_OK
  *    - ESP_FAIL
  */
esp_err_t uart_puts(char * str);

#endif /* #ifndef __UART_EXAMPLE_H__ */
