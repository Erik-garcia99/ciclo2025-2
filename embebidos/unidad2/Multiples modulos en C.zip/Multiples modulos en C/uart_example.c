#include <stdio.h>
#include <string.h>
#include "driver/uart.h"
#include "uart_example.h"


static uart_port_t app_uart_num = UART_NUM_MAX;


esp_err_t uart_init(uart_port_t uart_num, uint8_t tx_pin, uint8_t rx_pin, uint16_t tx_buffer_size, uint16_t rx_buffer_size)
{
    if (uart_num >= UART_NUM_MAX)
    {
        return ESP_FAIL;
    }
    
    uart_config_t uart_config = { /* La estructura también se puede recibir como parámetro para que la función sea más genérica */
        .baud_rate = 115200, 
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    
    app_uart_num = uart_num;
    
    // Configure UART parameters
    ESP_ERROR_CHECK(uart_param_config(app_uart_num, &uart_config));

    // Set UART pins
    ESP_ERROR_CHECK(uart_set_pin(app_uart_num, tx_pin, rx_pin, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));

    // Install UART driver
    ESP_ERROR_CHECK(uart_driver_install(app_uart_num, rx_buffer_size, \
                                            tx_buffer_size, 0, NULL, 0));
                                            
    return ESP_OK;  
}


esp_err_t uart_puts(char * str)
{
    if (app_uart_num >= UART_NUM_MAX)
    {
        return ESP_FAIL;
    }

    uint8_t len = strlen(str);
    uart_write_bytes(app_uart_num, (const char *) str, len);
    return ESP_OK;
}

